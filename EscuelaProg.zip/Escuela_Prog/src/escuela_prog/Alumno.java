/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package escuela_prog;

/**
 *
 * @author EAG
 */
public class Alumno {
    
    //Atributos
    protected String dni;
    protected String nombre;
    protected String apellidos;
    protected boolean pago;
    Nota Calificacion[];  
            
    //Constructores
    public Alumno( String dn, String no, String ape, boolean pa ){
        dni = dn;
        nombre = no;
        apellidos = ape;
        pago = pa;
    }
    
    public Alumno(String[] datos){
        if (datos.length >= 3) {
            dni = datos [0];
            nombre = datos [1];
            pago = datos [2].equals("true");
            apellidos = "";
        }
    }
    
    //Métodos GET/SET
    
    public String getDni(){
        return dni;
    }
    public String getNombre(){
        return nombre;
    }
    public String getApellidos(){
        return apellidos;
    }
    public boolean getPago(){
        return pago;
    }
    
    public void setDni( String dn ){
        dni = dn;
    }
    public void setClase( String no ){
        nombre = no;
    }
    public void setAnio( String ape  ){
        apellidos = ape;
    }
    public void setAnio( boolean pa ){
        pago = pa;
    }
    
    
    public String Volcado(){
        String tipoPago = pago ? "true" : "false";
        return dni + "-" + nombre + "-" + tipoPago;
}
    
    @Override
    public String toString(){
        return "Alumno : " + nombre + " " + apellidos + " | DNI: " + dni + " | Pago único: " + (pago ? "Sí" : "No");
    }
}

